@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python start_demo.py
) else (
  py -3.12 -c "import sys" >nul 2>nul
  if errorlevel 1 (py -3 start_demo.py) else (py -3.12 start_demo.py)
)
if errorlevel 1 pause
