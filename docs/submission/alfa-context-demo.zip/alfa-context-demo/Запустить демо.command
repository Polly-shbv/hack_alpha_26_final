#!/bin/sh
cd "$(dirname "$0")" || exit 1
TASK_PYTHON=""
for candidate in python3.12 python3.13 python3.11 python3; do
  if command -v "$candidate" >/dev/null 2>&1; then
    TASK_PYTHON="$candidate"
    break
  fi
done
if [ -z "$TASK_PYTHON" ]; then
  echo "Установите Python 3.12, затем повторите запуск."
  read -r reply
  exit 1
fi
"$TASK_PYTHON" start_demo.py
result=$?
if [ "$result" -ne 0 ]; then
  echo "Запуск завершился с ошибкой. Текст ошибки выше. Нажмите Enter."
  read -r reply
fi
exit "$result"
